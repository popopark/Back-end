const nodemailer = require("nodemailer");
const email = {

    host: "sandbox.smtp.mailtrap.io", 
    port: 25,
    auth: {
        user: "eddbd5ac405b3c",
        pass: "0ada29e9f3b49b"
    }
};

const send = async (option) => {
    nodemailer.createTransport(email).sendMail(option, (error, info) => {
        if (error) {
          console.log(error); 
        } else {
          console.log(info);
          return info.response; 
        }
    });
};


let data = {
    from: 'popo.park@daum.net',
    to: 'popo.park@daum.net',
    subject: '테스트 메일 입니다.',
    text: 'nodejs 한 시간만에 끝내보자.'
}

send(email_data);